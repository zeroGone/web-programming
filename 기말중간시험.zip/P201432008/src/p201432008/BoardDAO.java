package p201432008;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

public class BoardDAO {
	public static Board findOne(int id) throws Exception {
		String sql = "SELECT * FROM board where id=?";
		try (Connection connection = DB.getConnection("bbs2");
				PreparedStatement statement = connection.prepareStatement(sql)){
			statement.setInt(1, id);
			try(ResultSet resultSet = statement.executeQuery()) {
				if (resultSet.next()) {
					Board board = new Board();
					board.setId(resultSet.getInt("id"));
					board.setBoardName(resultSet.getString("boardName"));
					return board;
				}
			}
			return null;
		}
	}
	
	public static List<Board> findAll() throws Exception {
        String sql = "SELECT * FROM board";
        try (Connection connection = DB.getConnection("bbs2");
             PreparedStatement statement = connection.prepareStatement(sql);
             ResultSet resultSet = statement.executeQuery()) {
            ArrayList<Board> list = new ArrayList<Board>();
            while (resultSet.next()) {
                Board board = new Board();
                board.setId(resultSet.getInt("id"));
              	board.setBoardName(resultSet.getString("name"));
                list.add(board);
            }
            return list;
        }
    }
}
